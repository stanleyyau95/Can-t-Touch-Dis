


$(document).ready(function(){
	var questionNumber=0;
	var questionBank=new Array(); 
	var stage="#game1";
	var stage2=new Object;
	var questionLock=false;
	var numberOfQuestions;
	var score=0;

function getData(data){
	$.each(data.result.records, function(recordKey, recordValue){
		var recordAnswer=recordValue['English'];
		var recordLanguage1=recordValue['Yugara'];
		var recordLanguage2=recordValue['Yugambeh'];
		var recordLanguage3=recordValue['Yugara'];
		var recordID=recordValue['_id']; //1,6,7,10
/*		if(recordAnswer && recordLanguage && recordID){

			$('#records').append(
				$('<section class="record">').append(
					$('<h2>').text(recordLanguage),
					$('<p>').text(recordAnswer)
					).attr('id', 'record_'+recordID));
	}*/
	for(i=0; i<4;i++){
			questionBank[i]=new Array;
			questionBank[i][0]=recordAnswer;
			questionBank[i][1]=recordLanguage1;
			questionBank[i][2]=recordLanguage2;
			questionBank[i][3]=recordLanguage3;
		}
		nubmerOfQuestions=questionBank.length;
		
		displayQuestion();
	
});}
	

	


	function displayQuestion(){
		var rnd=Math.random()*3;
		rnd=Math.ceil(rnd);
		var q1;
 		var q2;
 		var q3; 
 		if(rnd==1){q1=questionBank[questionNumber][1];q2=questionBank[questionNumber][2];q3=questionBank[questionNumber][3];}
		if(rnd==2){q2=questionBank[questionNumber][1];q3=questionBank[questionNumber][2];q1=questionBank[questionNumber][3];}
		if(rnd==3){q3=questionBank[questionNumber][1];q1=questionBank[questionNumber][2];q2=questionBank[questionNumber][3];}
		$(stage).append('<div class="questionText">'+questionBank[questionNumber][0]+'</div><div id="1" class="option">'+q1+'</div><div id="2" class="option">'+q2+'</div><div id="3" class="option">'+q3+'</div>');

 		$('.option').click(function(){
 			if(questionLock==false){questionLock=true;	
 			//correct answer
 			if(this.id==rnd){
 				$(stage).append('<div class="feedback1">CORRECT</div>');
 				score++;
 			}
 			//wrong answer	
 			if(this.id!=rnd){
 				$(stage).append('<div class="feedback2">WRONG</div>');
 			}
 			setTimeout(function(){changeQuestion()},1000);
 		}})
	}//display question


	function changeQuestion(){
		
		questionNumber++;
	
	if(stage=="#game1"){stage2="#game1";stage="#game2";}
		else{stage2="#game2";stage="#game1";}
	
	if(questionNumber<numberOfQuestions){displayQuestion();}else{displayFinalSlide();}
	
	 $(stage2).animate({"right": "+=800px"},"slow", function() {$(stage2).css('right','-800px');$(stage2).empty();});
	 $(stage).animate({"right": "+=800px"},"slow", function() {questionLock=false;});
	}//change question





	function displayFinalSlide(){
		
		$(stage).append('<div class="questionText">You have finished the quiz!<br><br>Total questions: '+numberOfQuestions+'<br>Correct answers: '+score+'</div>');
		
	}//display final slide



	var data = {
	resource_id: '3e39dd7d-e777-4f47-9160-95aaca34bff5', // the resource id
    limit: 20, // get 5 results
    
  };
  $.ajax({
    url: 'http://data.gov.au/api/action/datastore_search',
    data: data,
    dataType: 'jsonp',
    cache: true,
    success: function(data) {
      getData(data);
      data=JSON.stringify(data);
    }
  });
});
